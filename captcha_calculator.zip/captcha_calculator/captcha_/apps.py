from django.apps import AppConfig


class CaptchaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'captcha_'
