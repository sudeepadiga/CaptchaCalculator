from django.urls import path
from . import views

urlpatterns = [
		path('', views.view, name='View'),
		path('captcha_add', views.captcha_add, name='Add'),
		path('captcha_multiply', views.captcha_multiply, name='Multiply'),
		path('captcha_reverse', views.captcha_reverse, name='Reverse'),
		path('validate_captcha', views.validate_captcha, name='Validate'),

	]