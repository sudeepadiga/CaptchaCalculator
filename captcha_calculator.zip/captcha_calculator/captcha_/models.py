from django.db import models
from django import forms
from captcha.fields import CaptchaField
from simplemathcaptcha.fields import MathCaptchaField

class CaptchaAddForm(forms.Form):
    # captcha = CaptchaField()
    captcha = MathCaptchaField()

class CaptchaMultiplyForm(forms.Form):
    # captcha = CaptchaField()
    captcha = MathCaptchaField(operator='*')

class CaptchaReverseForm(forms.Form):
    # captcha = CaptchaField()
    captcha = MathCaptchaField(operator='reverse')
