from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import *


def view(request):
	return render(request, 'view.html', {})

def captcha_add(request):
	if request.POST:
		form = CaptchaAddForm(request.POST)
		if form.is_valid():
			human = True
	else:
		form = CaptchaAddForm()
	return render(request, 'captcha_validation.html', {'form': form, 'title':'Add the Captcha'})

def captcha_multiply(request):
	if request.POST:
		form = CaptchaMultiplyForm(request.POST)
		if form.is_valid():
			human = True
	else:
		form = CaptchaMultiplyForm()
	return render(request, 'captcha_validation.html', {'form': form, 'title':'Multiply the Captcha'})

def captcha_reverse(request):
	if request.POST:
		form = CaptchaReverseForm(request.POST)
		if form.is_valid():
			human = True
	else:
		form = CaptchaReverseForm()
	return render(request, 'captcha_validation.html', {'form': form, 'title':'Reverse the Captcha'})

def validate_captcha(request):
	captcha_0 = request.POST.get('captcha_0')
	captcha_1 = request.POST.get('captcha_1')
	if captcha_0 == captcha_1:
		return render(request, 'captcha_result.html', {'msg': 'Success Page', 'color':'green', 'title':'Captcha Result'})
	else:
		return render(request, 'captcha_result.html', {'msg': 'Error Page', 'color':'red', 'title':'Captcha Result'})